﻿
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx4
{
    //Graph implementation for Assessed Exercise 4

    //Hints : 
    //Use lecture materials from Week 9A
    // and lab sheet 'Lab 9: Graphs Implementation' to aid with base implementation...

    //For 4B, review material from lecture 9B and lab 10 to aid with the implementation of these metrics

    //For 4C, see lecture 10A and lab 10 to aid with your traversal implementation

    //To address the last task for 4C, you can use BFS or DFS to as an idea of how to start off, but remember that we're only
    // interested in loot that can be obtained from the safest possible route, so we don't nessicarily need to find everything on the network as in
    // BFS and DFS!

    // - Adam.M

    class Graph<T> where T : IComparable
    {
        // A list of nodes in the graph
        private LinkedList<GraphNode<T>> nodes;

        // Constructor: Initializes the graph with an empty list of nodes
        public Graph()
        {
            nodes = new LinkedList<GraphNode<T>>();
        }

        // Add a new node to the graph
        public void AddNode(T id)
        {
            nodes.AddLast(new GraphNode<T>(id));
        }

        // Find and return a node in the graph by its ID
        public GraphNode<T> GetNodeByID(T id)
        {
            foreach (GraphNode<T> current in nodes)
            {
                // Compare the ID of the current node with the target ID
                if (current.ID.CompareTo(id) == 0)
                {
                    return current; // Return the matching node
                }
            }
            return null; // Return null if no matching node is found
        }

        // Add an edge between two nodes
        public void AddEdge(T from, T to)
        {
            GraphNode<T> n1 = GetNodeByID(from); // Find the starting node
            GraphNode<T> n2 = GetNodeByID(to);   // Find the destination node

            if (n1 != null && n2 != null)
            {
                n1.AddEdge(n2); // Add an edge from n1 to n2
            }
        }

        // Get the total number of nodes in the graph
        public int NumNodes()
        {
            return nodes.Count;
        }

        // Get the total number of edges in the graph
        public int NumEdges()
        {
            int count = 0;
            foreach (GraphNode<T> current in nodes)
            {
                count += current.GetAdjList().Count; // Add the count of adjacent nodes for each node
            }
            return count; // Return the total edge count
        }

        // Add a weighted edge between two nodes
        public void AddWeightedEdge(T from, T to, int weight)
        {
            GraphNode<T> n1 = GetNodeByID(from); // Find the starting node
            GraphNode<T> n2 = GetNodeByID(to);   // Find the destination node

            if (n1 != null && n2 != null)
            {
                n1.AddEdgeWithWeight(n2, weight); // Add a weighted edge from n1 to n2
            }
            else
            {
                Console.WriteLine("Error: One or both nodes not found.");
            }
        }

        // Calculate the average number of outbound edges per node
        public double AverageOutbound()
        {
            int totalEdges = NumEdges(); // Total number of edges in the graph
            int totalNodes = NumNodes(); // Total number of nodes in the graph

            if (totalNodes == 0) return 0; // Prevent division by zero if there are no nodes

            return (double)totalEdges / totalNodes; // Return the average
        }

        // Get a list of all adjacent nodes for a given node
        public List<T> GetAllAdjacencies(T id)
        {
            GraphNode<T> node = GetNodeByID(id); // Find the node by its ID

            if (node == null)
            {
                Console.WriteLine("Error: Node not found.");
                return null;
            }

            return node.GetAdjList().ToList(); // Convert the adjacency list to a standard list
        }

        // Calculate the average weight of edges in the graph
        public double AverageWeight()
        {
            int totalWeight = 0; // Accumulate total weights
            int totalEdges = NumEdges(); // Get the total number of edges

            if (totalEdges == 0) return 0; // Prevent division by zero if there are no edges

            foreach (var node in nodes)
            {
                var weights = node.Getweight(); // Get the weights of the node's edges
                totalWeight += weights.Sum();  // Add all weights to the total
            }

            return (double)totalWeight / totalEdges; // Return the average weight
        }

        // Breadth-First Search (BFS) traversal
        public void BFS(T startID, ref List<T> visited)
        {
            Queue<GraphNode<T>> queue = new Queue<GraphNode<T>>(); // Queue for BFS traversal
            HashSet<T> seen = new HashSet<T>(); // Set to track visited nodes

            GraphNode<T> startNode = GetNodeByID(startID); // Find the starting node
            if (startNode == null)
            {
                Console.WriteLine("Error: Starting node not found.");
                return;
            }

            queue.Enqueue(startNode); // Add the starting node to the queue
            seen.Add(startNode.ID);   // Mark the starting node as seen

            while (queue.Count > 0)
            {
                GraphNode<T> currentNode = queue.Dequeue(); // Remove the front node from the queue
                visited.Add(currentNode.ID);               // Add the node to the visited list

                // Iterate over all adjacent nodes (neighbors) of the current node
                foreach (T neighbor in currentNode.GetAdjList())
                {
                    // Logical NOT operator (!) checks if the neighbor has NOT been seen
                    if (!seen.Contains(neighbor))
                    {
                        queue.Enqueue(GetNodeByID(neighbor)); // Add the unseen neighbor to the queue
                        seen.Add(neighbor);                  // Mark the neighbor as seen
                    }
                }
            }
        }

        // Find the safest route (stub for now)
        public void SafestRoute(T startID, ref List<T> route)
        {
            // Placeholder for safest route implementation
        }
    }
}








//Free space, use as needed
