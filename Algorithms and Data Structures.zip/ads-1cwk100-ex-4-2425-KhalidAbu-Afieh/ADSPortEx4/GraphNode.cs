﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx4
{
    //Graph node implementation for Assessed Exercise 2

    //Hints : 
    //Use lecture materials from Week 9A
    // and lab sheet 'Lab 9: Graphs Implementation' to aid with base implementation...

    //Then see materials for week 10 when moving onto 4B

    // - Adam.M 


    // Definition of the generic class GraphNode<T> that represents a node in the graph.
    class GraphNode<T>
    {
        // Private field to store the node's ID (generic type T).
        private T id;

        // Private field to store the adjacency list, which is a linked list of neighboring node IDs.
        private LinkedList<T> adjList;

        // Private field to store the edge weights (linked list of integers) for the edges of this node.
        private LinkedList<int> weight;


        // Constructor that initializes the GraphNode with a given ID.
        public GraphNode(T id)
        {
            this.id = id; // Set the node's ID to the provided ID.

            // Initialize adjList as an empty LinkedList of type T to hold adjacent nodes.
            adjList = new LinkedList<T>();

            // Initialize weight as an empty LinkedList of type int to hold the weights of edges.
            weight = new LinkedList<int>();
        }

        // Property to get and set the ID of the node.
        public T ID
        {
            get { return id; } // Get the ID of the node.
            set { id = value; } // Set the ID of the node to the provided value.
        }

        // Method to add an edge from this node to another node (no weight considered here).
        public void AddEdge(GraphNode<T> to)
        {
            // Add the ID of the target node to the adjacency list (adjList) as a neighboring node.
            adjList.AddLast(to.id);
        }

        // Method to get the adjacency list of the node (all adjacent nodes).
        public LinkedList<T> GetAdjList()
        {
            return adjList; // Return the adjacency list (all neighboring nodes of this node).
        }

        // Function to get the list of edge weights for this node.
        public LinkedList<int> Getweight()
        {
            return weight; // Return the list of edge weights.
        }

        // Method to add an edge with a specified weight between this node and another node.
        public void AddEdgeWithWeight(GraphNode<T> to, int edgeWeight)
        {
            // Check if the provided edge weight is outside the valid range (1 to 10).
            if (edgeWeight < 1 || edgeWeight > 10)
            {
                Console.WriteLine("Error: Edge weight must be between 1 and 10."); // Print an error message if the weight is invalid.
                return; // Return without adding the edge if the weight is invalid.
            }

            // If the weight is valid, add the edge weight to the weight list.
            weight.AddLast(edgeWeight);
        }
    }
}

// End of class