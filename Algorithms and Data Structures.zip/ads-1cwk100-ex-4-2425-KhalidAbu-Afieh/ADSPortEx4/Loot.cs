﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx4
{
    // Definition of the Loot class that implements the IComparable interface.
    class Loot : IComparable
    {
        // Private field to store the name of the loot item.
        private string name;

        // Private field to store the value of the loot item.
        private double lootvalue;

        // Constructor that initializes a Loot object with a name and value.
        public Loot(string name, double lootvalue)
        {
            this.name = name; // Set the name of the loot item.
            this.lootvalue = lootvalue; // Set the loot value.
        }

        // Property to get and set the name of the loot item.
        public string Name
        {
            get { return name; } // Get the name of the loot item.
            set { name = value; } // Set the name of the loot item to the provided value.
        }

        // Property to get and set the loot value.
        public double LootValue
        {
            get { return lootvalue; } // Get the loot value.
            set { lootvalue = value; } // Set the loot value to the provided value.
        }

        // Method that implements the IComparable interface to compare loot items.
        public int CompareTo(object obj)
        {
            // Cast the object to a Loot instance for comparison.
            Loot other = (Loot)obj;

            // Compare the current loot item's name to the other loot item's name.
            return Name.CompareTo(other.Name); // Return comparison result (alphabetical order of names).
        }

        // Override of the ToString() method to provide a custom string representation of the Loot object.
        public override string ToString()
        {
            // Return a formatted string displaying the name and loot value.
            return $"Loot Name: {Name}, Loot Value: {LootValue}";
        }
    }
}
