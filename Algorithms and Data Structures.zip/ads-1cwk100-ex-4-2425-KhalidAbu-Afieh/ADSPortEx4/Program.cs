﻿using ADSPortEx4;
using System;
using System.Collections.Generic;

public class Program
{
    static void Main(string[] args)
    {
        // Create the graph to represent the loot network
        var graph = new Graph<string>(); // You can also use Loot type if you prefer



        // Menu-driven interface to allow the user to choose various graph operations.
        while (true)
        {
            // Clear the console for a fresh menu display.
            Console.Clear();

            // Display options to the user for interacting with the graph.
            Console.WriteLine("Loot Heist Planner");
            Console.WriteLine("1. Add Node (Loot)");
            Console.WriteLine("2. Add Edge (Pathway)");
            Console.WriteLine("3. Add Weighted Edge (Risk Factor)");
            Console.WriteLine("4. View Number of Nodes and Edges");
            Console.WriteLine("5. Average Number of Outbound Edges");
            Console.WriteLine("6. Average Weight of Edges");
            Console.WriteLine("7. Get All Adjacent Nodes");
            Console.WriteLine("8. Traversal (BFS)");
            Console.WriteLine("9. Safest Route (Minimize Risk)");
            Console.WriteLine("0. Exit");

            // Ask the user to input their choice of action.
            Console.Write("Enter your choice: ");
            var choice = Console.ReadLine();

            // Switch statement to handle different user choices based on input.
            switch (choice)
            {
                case "1":
                    // Add a Loot node to the graph
                    AddLootNode(graph);
                    break;

                case "2":
                    // Add an edge between nodes in the graph
                    AddEdge(graph);
                    break;

                case "3":
                    // Add a weighted edge (with risk factor) between nodes
                    AddWeightedEdge(graph);
                    break;

                case "4":
                    // View the number of nodes and edges in the graph
                    ViewNodeAndEdgeCount(graph);
                    break;

                case "5":
                    // View the average number of outbound edges from the nodes
                    ViewAverageOutboundEdges(graph);
                    break;

                case "6":
                    // View the average weight of the edges in the graph
                    ViewAverageWeight(graph);
                    break;

                case "7":
                    // Get and display all adjacent nodes of a specific node
                    GetAdjacencies(graph);
                    break;

                case "8":
                    // Perform BFS  traversal
                    TraversalChoice(graph);
                    break;

                case "9":
                    // Find the safest route (minimizing risk) between nodes
                    SafestRoute(graph);
                    break;

                default:
                    // If an invalid option is entered, notify the user and prompt to try again.
                    Console.WriteLine("Invalid option. Try again.");
                    break;
            }

            // Prompt the user to press any key to continue.
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
    }

    // Method to add a Loot node (with name and value) to the graph.
    private static void AddLootNode(Graph<string> graph)
    {
        // Prompt user to enter the loot's name.
        Console.Write("Enter loot name: ");
        string lootName = Console.ReadLine();

        // Prompt user to enter the loot's value, ensuring it's a valid numeric input.
        double lootValue;
        Console.Write("Enter loot value: ");
        while (!double.TryParse(Console.ReadLine(), out lootValue))
        {
            // Retry if the input is invalid.
            Console.Write("Invalid input. Please enter a valid numeric loot value: ");
        }

        // Create a new Loot object and add the node to the graph.
        Loot loot = new Loot(lootName, lootValue);
        graph.AddNode(lootName); // Add node to the graph with the given loot name.

        // Inform the user that the loot has been added successfully.
        Console.WriteLine($"Loot '{lootName}' added with value {lootValue}.");
    }

    // Method to add an edge (pathway) between two nodes in the graph.
    private static void AddEdge(Graph<string> graph)
    {
        // Prompt the user for the starting and destination node IDs.
        Console.Write("Enter starting node ID: ");
        string fromNode = Console.ReadLine();
        Console.Write("Enter destination node ID: ");
        string toNode = Console.ReadLine();

        // Add the edge between the two specified nodes.
        graph.AddEdge(fromNode, toNode);

        // Notify the user that the edge has been added.
        Console.WriteLine($"Edge added between {fromNode} and {toNode}.");
    }

    // Method to add a weighted edge (with a risk factor) between two nodes in the graph.
    private static void AddWeightedEdge(Graph<string> graph)
    {
        // Prompt the user for the starting and destination node IDs.
        Console.Write("Enter starting node ID: ");
        string fromNode = Console.ReadLine();
        Console.Write("Enter destination node ID: ");
        string toNode = Console.ReadLine();

        // Prompt the user for the weight of the edge (risk factor between 1 and 10).
        int weight;
        Console.Write("Enter edge weight (1-10): ");
        while (!int.TryParse(Console.ReadLine(), out weight) || weight < 1 || weight > 10)
        {
            // Retry if the input is invalid.
            Console.Write("Invalid input. Please enter a weight between 1 and 10: ");
        }

        // Add the weighted edge between the two nodes.
        graph.AddWeightedEdge(fromNode, toNode, weight);

        // Notify the user that the weighted edge has been added successfully.
        Console.WriteLine($"Weighted edge added between {fromNode} and {toNode} with weight {weight}.");
    }

    // Method to view and display the total number of nodes and edges in the graph.
    private static void ViewNodeAndEdgeCount(Graph<string> graph)
    {
        Console.WriteLine($"Total nodes: {graph.NumNodes()}"); // Output the total number of nodes in the graph.
        Console.WriteLine($"Total edges: {graph.NumEdges()}"); // Output the total number of edges in the graph.
    }

    // Method to view the average number of outbound edges from the nodes in the graph.
    private static void ViewAverageOutboundEdges(Graph<string> graph)
    {
        Console.WriteLine($"Average number of outbound edges: {graph.AverageOutbound():F2}"); // Output the average number of outbound edges formatted to two decimal places.
    }

    // Method to view the average weight of the edges in the graph.
    private static void ViewAverageWeight(Graph<string> graph)
    {
        Console.WriteLine($"Average weight of edges: {graph.AverageWeight():F2}"); // Output the average edge weight formatted to two decimal places.
    }

    // Method to view all adjacent nodes for a specific node in the graph.
    private static void GetAdjacencies(Graph<string> graph)
    {
        Console.Write("Enter node ID to view adjacent nodes: "); // Prompt the user for the node ID.
        string nodeId = Console.ReadLine();

        // Retrieve all adjacent nodes for the specified node.
        var adjacencies = graph.GetAllAdjacencies(nodeId);
        if (adjacencies != null && adjacencies.Count > 0)
        {
            // Display the list of adjacent nodes.
            Console.WriteLine($"Adjacent nodes to {nodeId}: {string.Join(", ", adjacencies)}");
        }
        else
        {
            // If no adjacent nodes found, notify the user.
            Console.WriteLine($"No adjacent nodes found for {nodeId}.");
        }
    }

    // Method to handle BFS or DFS traversal based on user input.
    private static void TraversalChoice(Graph<string> graph)
    {
        Console.WriteLine("Select Traversal Method:");
        Console.WriteLine("1. BFS (Breadth-First Search)"); // Option for BFS traversal.
        Console.Write("Enter your choice: ");
        var traversalChoice = Console.ReadLine();

        Console.Write("Enter starting node ID: ");
        string startId = Console.ReadLine();

        // List to store visited nodes during traversal.
        var visited = new List<string>();

        switch (traversalChoice)
        {
            case "1":
                // Perform BFS traversal.
                graph.BFS(startId, ref visited);
                Console.WriteLine("BFS Traversal Result:");
                break;

            default:
                // If an invalid option is selected, notify the user.
                Console.WriteLine("Invalid option for traversal. Returning to main menu.");
                return;
        }

        // Output the result of the traversal (list of visited nodes).
        Console.WriteLine(string.Join(", ", visited));
    }

    // Method to find and display the safest route between two nodes (minimizing risk).
    private static void SafestRoute(Graph<string> graph)
    {

    }
}