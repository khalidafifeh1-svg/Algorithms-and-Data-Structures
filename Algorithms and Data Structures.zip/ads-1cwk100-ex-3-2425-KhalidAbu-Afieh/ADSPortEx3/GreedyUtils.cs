﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx3
{
    class GreedyUtils
    {
        //Greedy algorithm implementation for Assessed Exercise 3

        //Hints : 
        //Use lecture materials from Week 8
        // to aid with implementation...

        //You can take a list of items obtained from the user in the menu driven interface then convert it into
        // an array as you work your way towards a viable solution.

        //The delivered solution cannot exceed a weight limit of 100KG, make sure you are keeping track of this


        // - Adam.M 


        // Method to get the optimal list of items based on a greedy approach
        public static List<Item> GetGreedyManifesto(List<Item> items, double limit)
        {
            // Sort the items using the CompareTo method implemented in the Item class.
            items.Sort();

            // Create a list to hold the selected items
            List<Item> selectedItems = new List<Item>();

            // Variable to track the total weight of selected items
            double totalWeight = 0;

            // Iterate through the sorted items to select those that fit within the weight limit
            foreach (var item in items)
            {
                // If adding this item doesn't exceed the weight limit, add it to the selected list
                if (totalWeight + item.Weight <= limit)
                {
                    selectedItems.Add(item); // Add the item to the list of selected items
                    totalWeight += item.Weight;  // Update the total weight with the weight of the selected item
                }
                else
                {
                    // If adding this item exceeds the weight limit, stop adding further items
                    break;
                }
            }

            // Return the list of selected items that fit within the weight limit
            return selectedItems;
        }
    }
}
