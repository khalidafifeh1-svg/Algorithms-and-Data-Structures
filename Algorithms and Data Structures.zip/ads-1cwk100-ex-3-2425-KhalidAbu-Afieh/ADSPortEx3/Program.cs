﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create a menu-driven interface where the user can interact with your implementations
            // I.e., while(true) {  
            //     Print to the user: "Select an option"
            //     "1. Demo sort..."
            //     "2. Add item for greedy algorithm..." 
            // }

            // You won't need to create either of the utils classes, both use static methods.
            // I.e., SortUtils.InsertSort();
            // GreedyUtils.GetGreedyManifesto();

            while (true)
            {
                // Prompt the user to select a data type to sort
                Console.WriteLine("Select Data Type to Sort:");
                Console.WriteLine("1. Integers");
                Console.WriteLine("2. Strings");
                Console.WriteLine("3. Add item for Greedy");

                Console.WriteLine("4. Exit");

                // Ask the user to enter their choice (1-4)
                Console.Write("Enter your choice (1-4): ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        // Sort integers
                        SortIntegers();
                        break;

                    case "2":
                        // Sort strings
                        SortStrings();
                        break;

                    case "3":
                        // Add item for Greedy algorithm
                        AddItemForGreedyAlgorithm();
                        return;  // Exit the program after performing the greedy operation

                    case "4":
                        // Exit the program
                        Console.WriteLine("Exiting the program...");
                        return;

                    default:
                        // If the user enters an invalid choice, display an error message
                        Console.WriteLine("Invalid choice. Please enter 1, 2, or 3.");
                        break;
                }
                Console.WriteLine("\nDo you want to go back to the main menu? (y) ");
                string goBack = Console.ReadLine();
                if (goBack.ToLower() != "y")
                {
                    Console.WriteLine("Exiting the program...");
                    return;

                }
                // Clear the console screen to reset the view and show the main menu again
                Console.Clear();
            }
        }





        // Function to handle sorting of integers
        static void SortIntegers()
        {
            // Prompt the user to enter integers to sort (comma-separated)
            Console.WriteLine("Enter integers to sort (comma-separated):");
            string inputIntegers = Console.ReadLine();
            try
            {


                // Convert the input string to an array of integers
                int[] intArray = Array.ConvertAll(inputIntegers.Split(' '), int.Parse);

            // Call the InsertSort method to sort the array of integers
            SortUtils.InsertSortGen(intArray);

            // Display the sorted integers
            Console.WriteLine("Sorted Integers: " + string.Join(" ", intArray));
        }
            catch (FormatException)
            {
                Console.WriteLine("Error: Please ensure you enter valid integers separated by commas.");
            }
}

        // Function to handle sorting of strings
        static void SortStrings()
        {
            // Prompt the user to enter strings to sort (comma-separated)
            Console.WriteLine("Enter strings to sort (comma-separated):");
            string inputStrings = Console.ReadLine();

            // Split the input string into an array of strings
            string[] stringArray = inputStrings.Split(' ');

            // Call the InsertSort method to sort the array of strings
            SortUtils.InsertSortGen(stringArray);

            // Display the sorted strings
            Console.WriteLine("Sorted Strings: " + string.Join(" ", stringArray));
        }

        // Function for adding items for the Greedy Algorithm (Task C)
        static void AddItemForGreedyAlgorithm()
        {
            // Create a list to hold the items
            List<Item> items = new List<Item>();
            string continueInput = "y";

            // Loop to allow the user to keep adding items
            while (continueInput.ToLower() == "y")
            {
                // Ask the user to input the item's name (or description)
                Console.WriteLine("Enter item name or description: ");
                string name = Console.ReadLine();

                // Ask for the item's value (between 1 and 10)
                Console.WriteLine("Enter item value (1-10): ");
                int value = int.Parse(Console.ReadLine());

                // Ask for the item's weight (in kg)
                Console.WriteLine("Enter item weight (in kg): ");
                int weight = int.Parse(Console.ReadLine());

                // Create a new item object with the provided name, value, and weight
                Item item = new Item(name, value, weight);

                // Add the item to the list of items
                items.Add(item);

                // Ask if the user wants to add another item
                Console.WriteLine("Do you want to add another item? (y/n)");
                continueInput = Console.ReadLine();
            }

            // Run the Greedy algorithm to select items for the payload
            Console.WriteLine("Running Greedy Algorithm...");
            var selectedItems = GreedyUtils.GetGreedyManifesto(items, 100);  // Assume max weight is 100 kg

            // Calculate total weight, total value, and total value-to-weight ratio
            int totalWeight = (int)selectedItems.Sum(item => item.Weight);
            int totalValue = selectedItems.Sum(item => item.Value);
            double totalValRatio = selectedItems.Sum(item => item.ValRatio);

            // Calculate how much weight is left
            int remainingWeight = 100 - totalWeight;  // 100 kg weight limit

            // Display the optimized payload (items selected by the greedy algorithm)
            Console.WriteLine("Optimized Payload (Items selected):");
            foreach (var selectedItem in selectedItems)
            {
                Console.WriteLine($"Item - Name: {selectedItem.Name}, Value: {selectedItem.Value}, Weight: {selectedItem.Weight}, Value/Weight Ratio: {selectedItem.ValRatio:F2}");
            }

            // Display the total weight, total value, value-to-weight ratio, and remaining weight
            Console.WriteLine("\nTotal Weight: " + totalWeight + " Kgs");
            Console.WriteLine("Total Value: " + totalValue);
            Console.WriteLine("Total Value/Weight Ratio: " + totalValRatio.ToString("F2"));
            Console.WriteLine("Remaining Weight: " + remainingWeight + " Kgs");
            Console.ReadLine();
        }
    }
}




