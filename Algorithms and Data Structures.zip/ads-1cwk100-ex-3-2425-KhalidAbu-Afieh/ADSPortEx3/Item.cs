﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx3
{
    //Item class implementation for Assessed Exercise 3

    //For use as part of EX.3C

    //Use slides from Week 8A regarding the knapsack algorithm example to aid with implementation

    class Item : IComparable  // Defines a class named Item that implements the IComparable interface, allowing item comparison.
    {
        // Private fields to store item attributes (name, value, and weight).
        private string name;  // Holds the name of the item.
        private int value;  // Holds the value of the item (integer).
        private double weight;  // Holds the weight of the item (floating-point number).

        // Constructor to initialize the Item object with a name, value, and weight.
        public Item(string name, int value, int weight)
        {
            this.name = name;  // Assigns the parameter name to the private name field.
            this.value = value;  // Assigns the parameter value to the private value field.
            this.weight = weight;  // Assigns the parameter weight to the private weight field.
        }

        // Property to get and set the name of the item.
        public string Name
        {
            get { return name; }  // Returns the current name of the item.
            set { name = value; }  // Updates the item's name.
        }

        // Property to get and set the value of the item.
        public int Value
        {
            get { return value; }  // Returns the current value of the item.
            set { this.value = value; }  // Updates the item's value.
        }

        // Property to get and set the weight of the item.
        public double Weight
        {
            get { return weight; }  // Returns the current weight of the item.
            set { weight = value; }  // Updates the item's weight.
        }

        // Read-only property that calculates the value-to-weight ratio.
        public double ValRatio
        {
            get { return Value / Weight; }  // Divides the value by the weight to calculate the value-to-weight ratio.
        }

        // Method to compare Item objects based on their value-to-weight ratio.
        public int CompareTo(object obj)
        {
            Item other = (Item)obj;  // Casts the input object to an Item type for comparison.
            return ValRatio.CompareTo(other.ValRatio);  // Compares value-to-weight ratios, returning a positive or negative value based on the comparison.
        }
    }
}