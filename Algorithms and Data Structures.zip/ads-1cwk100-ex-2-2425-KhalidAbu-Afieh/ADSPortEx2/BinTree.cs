﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx2
{
    // Binary Tree implementation for Assessed Exercise 2

    // Hints:
    // - Use lecture materials from Week 4B
    // - Refer to lab sheet 'Lab 5: BinTree and BSTree' for implementation guidance

    // Author: Adam.M

    // Generic Binary Tree Class
    // T must implement the IComparable interface to allow comparisons
    class BinTree<T> where T : IComparable
    {
        // Protected root node of the binary tree
        protected Node<T> root;

        // Default constructor: Initializes an empty binary tree
        public BinTree()
        {
            root = null;
        }

        // Constructor: Initializes a binary tree with a given root node
        public BinTree(Node<T> node)
        {
            root = node;
        }

        // Functions for EX.2A - Tree Traversal Methods

        // Public method to perform an InOrder traversal
        // Traverses the tree in the order: Left -> Root -> Right
        public void InOrder(ref string buffer)
        {
            inOrder(root, ref buffer);
        }

        // Private recursive helper method for InOrder traversal
        private void inOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null) // Check if the current node is not null
            {
                inOrder(tree.Left, ref buffer); // Traverse the left subtree
                buffer += tree.Data.ToString() + " , "; // Visit the current node
                inOrder(tree.Right, ref buffer); // Traverse the right subtree
            }
        }

        // Public method to perform a PreOrder traversal
        // Traverses the tree in the order: Root -> Left -> Right
        public void PreOrder(ref string buffer)
        {
            preOrder(root, ref buffer);
        }

        // Private recursive helper method for PreOrder traversal
        private void preOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null) // Check if the current node is not null
            {
                buffer += tree.Data.ToString() + " , "; // Visit the current node
                preOrder(tree.Left, ref buffer); // Traverse the left subtree
                preOrder(tree.Right, ref buffer); // Traverse the right subtree
            }
        }

        // Public method to perform a PostOrder traversal
        // Traverses the tree in the order: Left -> Right -> Root
        public void PostOrder(ref string buffer)
        {
            postOrder(root, ref buffer);
        }

        // Private recursive helper method for PostOrder traversal
        private void postOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null) // Check if the current node is not null
            {
                postOrder(tree.Left, ref buffer); // Traverse the left subtree
                postOrder(tree.Right, ref buffer); // Traverse the right subtree
                buffer += tree.Data.ToString() + " , "; // Visit the current node
            }
        }
    }
    //Free space, use as necessary to address task requirements... 
    // End of class
}
