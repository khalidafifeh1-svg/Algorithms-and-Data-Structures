﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx2
{
    // Node (tree) implementation for Assessed Exercise 2

    // Hints: 
    // Use lecture materials from Week 4B 
    // and the lab sheet 'Lab 5: BinTree and BSTree' to aid with implementation.

    // Class Node<T> represents a node in a binary tree.
    // The generic type 'T' must implement the IComparable interface.
    class Node<T> where T : IComparable
    {
        // Public field to store the data for the node.
        public T data;

        // References to the left and right child nodes.
        public Node<T> Left, Right;

        // Private field to store the balance factor of the node (used for AVL trees).
        private int balanceFactor = 0;

        // Private field to store the height of the node.
        private int height = 0;

        // Constructor: Initializes the node with the given item.
        // Sets both child nodes (Left and Right) to null.
        public Node(T item)
        {
            data = item;    // Assign the item to the 'data' field.
            Left = null;    // Initialize the left child as null.
            Right = null;   // Initialize the right child as null.
        }

        // Property to get or set the data of the node.
        public T Data
        {
            get { return data; }  // Returns the data stored in the node.
            set { data = value; } // Updates the data with the specified value.
        }

        // Property to get or set the height of the node.
        public int Height
        {
            get { return height; }  // Returns the current height of the node.
            set { height = value; } // Updates the height with the specified value.
        }

    } // End of class Node<T>

} // End of namespace ADSPortEx2
