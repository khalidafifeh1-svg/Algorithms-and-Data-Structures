﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx2
{
    // Binary Search Tree implementation for Assessed Exercise 2.

    // Hints:
    // Use lecture materials from Week 5
    // and the lab sheet 'Lab 5: BinTree and BSTree' to aid with implementation.

    // For the Update function in Task 2B, consider the different cases that can occur
    // during the insert recursion and think about how you can navigate the tree 
    // to find and update the correct node.

    // - Adam.M 

    // BSTree class implementation
    // Inherits from BinTree<T> and uses the IComparable interface to allow comparisons
    class BSTree<T> : BinTree<T> where T : IComparable
    {
        // Constructor: Initializes the binary search tree with a null root.
        public BSTree()
        {
            root = null; // Set root node to null.
        }

        // EX.2A: Insert an item into the binary search tree.
        public void InsertItem(T item)
        {
            insertItem(item, ref root); // Calls the private insert function.
        }

        // Private recursive function to insert an item into the correct position in the tree.
        private void insertItem(T item, ref Node<T> tree)
        {
            if (tree == null)
            {
                // If the current node is null, create a new node here.
                tree = new Node<T>(item);
            }
            else if (item.CompareTo(tree.Data) < 0)
            {
                // If the item is smaller, insert it into the left subtree.
                insertItem(item, ref tree.Left);
            }
            else if (item.CompareTo(tree.Data) > 0)
            {
                // If the item is larger, insert it into the right subtree.
                insertItem(item, ref tree.Right);
            }
            // If equal, do nothing (assuming no duplicates are allowed).
        }

        // EX.2A: Calculate the height of the binary search tree.
        public int Height()
        {
            return height(root); // Calls the private height function.
        }

        // Private recursive function to calculate the height of the tree.
        private int height(Node<T> tree)
        {
            if (tree == null)
            {
                return 0; // Height of an empty tree is 0.
            }
            else
            {
                // Height is 1 (current node) plus the maximum of the left and right subtree heights.
                return 1 + Math.Max(height(tree.Left), height(tree.Right));
            }
        }

        // EX.2B: Count the total number of nodes in the binary search tree.
        public int Count()
        {
            return Count(root); // Calls the private count function.
        }

        // Private recursive function to count the number of nodes in the tree.
        private int Count(Node<T> tree)
        {
            if (tree == null)
            {
                return 0; // Base case: no nodes in an empty tree.
            }
            else
            {
                // Count the current node (1) and recursively count nodes in the left and right subtrees.
                return 1 + Count(tree.Left) + Count(tree.Right);
            }
        }

        // EX.2B: Update the data of a specific node in the tree.
        public void Update(T item)
        {
            // Start searching for the node that needs to be updated.
            update(item, ref root);
        }

        // Private recursive function to update the data of a specific node in the tree.
        private void update(T item, ref Node<T> tree)
        {
            if (tree == null)
            {
                // If the tree is empty or the item is not found.
                Console.WriteLine("Film not found in the tree.");
                return;
            }

            // Compare the item with the current node's data to navigate the tree.
            int comparison = item.CompareTo(tree.Data);
            if (comparison < 0)
            {
                // If the item is smaller, search the left subtree.
                update(item, ref tree.Left);
            }
            else if (comparison > 0)
            {
                // If the item is larger, search the right subtree.
                update(item, ref tree.Right);
            }
            else
            {
                // If the item matches the current node's data.
                tree.Data = item; // Update the node's data with the new value.
                Console.WriteLine("Film updated successfully.");
            }
        }

        // Additional space to implement any other functions or requirements as needed.




    }// End of class
}
