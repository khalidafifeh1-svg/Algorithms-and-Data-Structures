﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ADSPortEx2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AVLTree<Film> filmTree = new AVLTree<Film>();

            // Insert films into the tree (Not implemented yet)

            // Menu loop to present the user with options
            while (true)
            {
                Console.Clear(); // Clear the console to start fresh each time the menu is displayed

                Console.WriteLine("=== Menu Film ===");
                Console.WriteLine("1. Add a new film");
                Console.WriteLine("2. Remove a film");
                Console.WriteLine("3. Display tree (InOrder, PreOrder, PostOrder)");
                Console.WriteLine("4. Display tree height");
                Console.WriteLine("5. Display film count");
                Console.WriteLine("6. Update an existing film");
                Console.WriteLine("7. Exit");
                Console.Write("Choose an option: ");
                string choice = Console.ReadLine(); // Get the user's choice input

                switch (choice)
                {
                    case "1":
                        // Add a new film
                        AddFilm(filmTree);
                        break;
                    case "2":
                        // Remove a film (Not implemented yet)
                        RemoveFilm(filmTree);
                        break;
                    case "3":
                        // Display tree traversal
                        DisplayTreeTraversal(filmTree);
                        break;
                    case "4":
                        // Display tree height
                        DisplayTreeHeight(filmTree);
                        break;
                    case "5":
                        // Display film count
                        DisplayFilmCount(filmTree);
                        break;
                    case "6":
                        // Update an existing film (Not implemented yet)
                        UpdateFilm(filmTree);
                        break;
                    case "7":
                        Console.WriteLine("Exiting the application. Goodbye!");
                        return; // Exit the program
                    default:
                        Console.WriteLine("Invalid choice. Please select a valid option.");
                        break;
                }
            }
        }

        static void AddFilm(BSTree<Film> filmTree)
        {
            Console.Clear(); // Clear the screen for adding a film
            Console.WriteLine("=== Add a New Film ===");
            Console.Write("Enter the title of the film: ");
            string title = Console.ReadLine(); // User input for film title

            Console.Write("Enter the director of the film: ");
            string director = Console.ReadLine(); // User input for film director

            Console.Write("Enter the quantity of the film: ");
            if (!int.TryParse(Console.ReadLine(), out int quantity) || quantity < 0)
            {
                // The '||' operator is logical OR - check if the quantity is invalid or less than 0
                Console.WriteLine("Invalid quantity. Please enter a positive integer.");
                Console.WriteLine("Press any key to return to the menu...");
                Console.ReadKey();
                return; // Exit the method if quantity is invalid
            }

            Film newFilm = new Film(title, director, quantity); // Create a new Film object
            filmTree.InsertItem(newFilm); // Insert the new film into the AVL tree

            Console.WriteLine($"Film \"{title}\" by {director} added successfully with quantity {quantity}.");
            Console.WriteLine("Press any key to return to the menu...");
            Console.ReadKey(); // Wait for user input to return to the menu
        }

        private static void DisplayTreeTraversal(BSTree<Film> filmTree)
        {
            Console.Clear(); // Clear the screen for tree traversal options
            Console.WriteLine("\nChoose traversal method:");
            Console.WriteLine("1. InOrder");
            Console.WriteLine("2. PreOrder");
            Console.WriteLine("3. PostOrder");
            Console.Write("Enter your choice: ");
            string traversalChoice = Console.ReadLine(); // User input for traversal method

            string buffer = string.Empty;  // Clear buffer before each traversal

            // The 'switch' statement is used to choose which traversal method to use
            switch (traversalChoice)
            {
                case "1":
                    filmTree.InOrder(ref buffer); // Perform InOrder traversal
                    Console.WriteLine("\nInOrder Traversal:");
                    Console.WriteLine(buffer.Length > 0 ? buffer : "Tree is empty."); // Ternary operator to check if buffer is empty
                    break;
                case "2":
                    filmTree.PreOrder(ref buffer); // Perform PreOrder traversal
                    Console.WriteLine("\nPreOrder Traversal:");
                    Console.WriteLine(buffer.Length > 0 ? buffer : "Tree is empty."); // Ternary operator to check if buffer is empty
                    break;
                case "3":
                    filmTree.PostOrder(ref buffer); // Perform PostOrder traversal
                    Console.WriteLine("\nPostOrder Traversal:");
                    Console.WriteLine(buffer.Length > 0 ? buffer : "Tree is empty."); // Ternary operator to check if buffer is empty
                    break;
                default:
                    Console.WriteLine("Invalid choice for traversal method.");
                    break;
            }
            Console.WriteLine("\nPress any key to return to the menu...");
            Console.ReadKey(); // Wait for user input to return to the menu
        }

        private static void DisplayTreeHeight(BSTree<Film> filmTree)
        {
            Console.Clear(); // Clear the screen to show tree height
            int treeHeight = filmTree.Height(); // Get the height from the tree
            Console.WriteLine($"\nThe height of the tree is: {treeHeight}");
            Console.WriteLine("Press any key to return to the menu...");
            Console.ReadKey(); // Wait for user input to return to the menu
        }

        private static void DisplayFilmCount(BSTree<Film> filmTree)
        {
            Console.Clear(); // Clear the screen to show film count
            int filmCount = filmTree.Count(); // Get the total film count in the tree
            Console.WriteLine($"\nTotal number of films in the tree: {filmCount}");
            Console.WriteLine("Press any key to return to the menu...");
            Console.ReadKey(); // Wait for user input to return to the menu
        }

        static void UpdateFilm(BSTree<Film> filmTree)
        {
            Console.Clear(); // Clear the screen for updating a film
            Console.WriteLine("=== Update an Existing Film ===");

            Console.Write("Enter the title of the film to update: ");
            string title = Console.ReadLine(); // User input for the film title to update

            // You can optionally let the user update other details, like director and quantity:
            Console.Write("Enter the new director of the film: ");
            string director = Console.ReadLine(); // User input for new director

            Console.Write("Enter the new quantity of the film: ");
            if (!int.TryParse(Console.ReadLine(), out int quantity) || quantity < 0)
            {
                // The '||' operator is logical OR - check if the quantity is invalid or less than 0
                Console.WriteLine("Invalid quantity. Please enter a positive integer.");
                Console.WriteLine("Press any key to return to the menu...");
                Console.ReadKey();
                return; // Exit the method if quantity is invalid
            }

            Film updatedFilm = new Film(title, director, quantity); // Create a new updated Film object
            filmTree.Update(updatedFilm); // Call the Update method to update the film data

            Console.WriteLine($"Film \"{title}\" has been updated.");
            Console.WriteLine("Press any key to return to the menu...");
            Console.ReadKey(); // Wait for user input to return to the menu
        }

        static void RemoveFilm(AVLTree<Film> filmTree)
        {
            Console.Clear(); // Clear the screen for removing a film
            Console.WriteLine("=== Remove a Film ===");
            Console.Write("Enter the title of the film to remove: ");
            string title = Console.ReadLine(); // User input for the title of the film to remove

            Film filmToRemove = new Film(title, string.Empty, 0); // Create a new Film object with only the title for removal
            filmTree.RemoveItem(filmToRemove); // Remove the film from the tree

            Console.WriteLine($"Film \"{title}\" has been removed (if it existed).");
            Console.WriteLine("Press any key to return to the menu...");
            Console.ReadKey(); // Wait for user input to return to the menu
        }
    }
}
