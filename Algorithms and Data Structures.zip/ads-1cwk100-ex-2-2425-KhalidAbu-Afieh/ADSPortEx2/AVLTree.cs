﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx2
{
    // AVL Tree implementation for Assessed Exercise 2

    // Hints: 
    // Use lecture materials from Week 6A
    // and lab sheet 'Lab 6: AVL Trees' to aid with implementation...

    // You may need to adjust your other tree classes to allow your AVL tree
    // access to certain attributes and functions.

    // See Lecture 5B for pointers on how to implement node removal within your tree.

    // Don't forget to properly check and test your rotations, it's the whole point
    // of AVL Trees!

    // - Adam.M 

    class AVLTree<T> : BSTree<T> where T : IComparable
    {
        // Public InsertItem method to insert an item into the AVL tree.
        public new void InsertItem(T item)
        {
            root = InsertItem(item, root); // Calls the recursive InsertItem method with the root node.
        }

        // Private recursive method to insert an item into the AVL tree.
        private Node<T> InsertItem(T item, Node<T> node)
        {
            if (node == null)
            {
                return new Node<T>(item); // If the node is null, create a new node with the item.
            }

            // If the item is smaller than the current node's data, insert it into the left subtree.
            if (item.CompareTo(node.Data) < 0)
            {
                node.Left = InsertItem(item, node.Left);
            }
            // If the item is larger than the current node's data, insert it into the right subtree.
            else if (item.CompareTo(node.Data) > 0)
            {
                node.Right = InsertItem(item, node.Right);
            }
            else
            {
                // If the item is already in the tree, we do not insert it again.
                return node;
            }

            // Update height of the current node.
            node.Height = 1 + Math.Max(Height(node.Left), Height(node.Right));
            int balanceFactor = GetBalance(node); // Get the balance factor of the current node.

            // Apply rotations if the tree is unbalanced.
            if (balanceFactor > 1 && item.CompareTo(node.Left.Data) < 0)
                return RotateRight(node); // Left-Left case: perform a right rotation.

            if (balanceFactor < -1 && item.CompareTo(node.Right.Data) > 0)
                return RotateLeft(node); // Right-Right case: perform a left rotation.

            if (balanceFactor > 1 && item.CompareTo(node.Left.Data) > 0)
            {
                node.Left = RotateLeft(node.Left); // Left-Right case: perform a left rotation on the left child.
                return RotateRight(node); // Then perform a right rotation on the current node.
            }

            if (balanceFactor < -1 && item.CompareTo(node.Right.Data) < 0)
            {
                node.Right = RotateRight(node.Right); // Right-Left case: perform a right rotation on the right child.
                return RotateLeft(node); // Then perform a left rotation on the current node.
            }

            return node; // Return the (possibly rotated) node.
        }

        // Public method to remove an item from the AVL tree.
        public void RemoveItem(T item)
        {
            root = RemoveItem(ref root, item); // Calls the recursive RemoveItem method with the root node.
        }

        // Private recursive method to remove an item from the AVL tree.
        private Node<T> RemoveItem(ref Node<T> tree, T item)
        {
            if (tree == null)
            {
                return null; // If the tree is empty, return null.
            }

            // If the item is smaller than the current node's data, remove it from the left subtree.
            if (item.CompareTo(tree.Data) < 0)
            {
                tree.Left = RemoveItem(ref tree.Left, item); // Recursively go left.
            }
            // If the item is larger than the current node's data, remove it from the right subtree.
            else if (item.CompareTo(tree.Data) > 0)
            {
                tree.Right = RemoveItem(ref tree.Right, item); // Recursively go right.
            }
            else
            {
                // Node to be deleted found.
                if (tree.Left == null && tree.Right == null)
                {
                    tree = null; // No children, just remove the node.
                }
                else if (tree.Left == null)
                {
                    tree = tree.Right; // Only right child, promote the right child.
                }
                else if (tree.Right == null)
                {
                    tree = tree.Left; // Only left child, promote the left child.
                }
                else
                {
                    // Node with two children: get the inorder successor (smallest in the right subtree).
                    Node<T> minNode = FindMin(tree.Right);
                    tree.Data = minNode.Data; // Replace the current node with the inorder successor.
                    tree.Right = RemoveItem(ref tree.Right, minNode.Data); // Remove the inorder successor from the right subtree.
                }
            }

            // Update height and balance after removal.
            if (tree != null)
            {
                tree.Height = 1 + Math.Max(Height(tree.Left), Height(tree.Right)); // Update the height of the current node.
                int balance = GetBalance(tree); // Get the balance factor of the current node.

                // Balance the tree if needed.
                if (balance > 1)
                {
                    if (GetBalance(tree.Left) >= 0)
                        tree = RotateRight(tree); // Perform right rotation if the left subtree is balanced or left-heavy.
                    else
                    {
                        tree.Left = RotateLeft(tree.Left); // Left-Right case: left rotation on the left child.
                        tree = RotateRight(tree); // Then right rotation on the current node.
                    }
                }
                else if (balance < -1)
                {
                    if (GetBalance(tree.Right) <= 0)
                        tree = RotateLeft(tree); // Perform left rotation if the right subtree is balanced or right-heavy.
                    else
                    {
                        tree.Right = RotateRight(tree.Right); // Right-Left case: right rotation on the right child.
                        tree = RotateLeft(tree); // Then left rotation on the current node.
                    }
                }
            }

            return tree; // Return the (possibly rotated) tree.
        }

        // Left rotation on a node.
        private Node<T> RotateLeft(Node<T> node)
        {
            Node<T> newRoot = node.Right; // Set the new root to be the right child.
            node.Right = newRoot.Left; // Make the left child of the new root the right child of the current node.
            newRoot.Left = node; // Make the current node the left child of the new root.

            // Update heights of the rotated nodes.
            node.Height = 1 + Math.Max(Height(node.Left), Height(node.Right));
            newRoot.Height = 1 + Math.Max(Height(newRoot.Left), Height(newRoot.Right));

            return newRoot; // Return the new root of the subtree.
        }

        // Right rotation on a node.
        private Node<T> RotateRight(Node<T> node)
        {
            Node<T> newRoot = node.Left; // Set the new root to be the left child.
            node.Left = newRoot.Right; // Make the right child of the new root the left child of the current node.
            newRoot.Right = node; // Make the current node the right child of the new root.

            // Update heights of the rotated nodes.
            node.Height = 1 + Math.Max(Height(node.Left), Height(node.Right));
            newRoot.Height = 1 + Math.Max(Height(newRoot.Left), Height(newRoot.Right));

            return newRoot; // Return the new root of the subtree.
        }

        // Helper method to get the height of a node.
        private int Height(Node<T> node)
        {
            return node == null ? 0 : node.Height; // Ternary operator: if node is null, return 0, otherwise return node.Height.
        }

        // Helper method to get the balance factor of a node.
        private int GetBalance(Node<T> node)
        {
            return node == null ? 0 : Height(node.Left) - Height(node.Right); // Ternary operator: if node is null, return 0, else return left height - right height.
        }

        // Helper method to find the minimum node in a subtree.
        private Node<T> FindMin(Node<T> node)
        {
            while (node.Left != null)
            {
                node = node.Left; // Keep traversing left to find the minimum (leftmost) node.
            }
            return node; // Return the minimum node.
        }




        //Free space, use as required






    }// End of class
}
