﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx2
{
    // Film class implementation for Assessed Exercise 2

    // This class represents a film with a title, director, and quantity available.
    // It implements the IComparable interface to allow sorting films by their title.

    class Film : IComparable
    {
        // Private fields to store the film's title, director, and quantity.
        private string title;      // Title of the film.
        private string director;   // Director of the film.
        private int quantity;      // Quantity of the film available.

        // Constructor to initialize a Film object with a title, director, and quantity.
        public Film(string title, string director, int quantity)
        {
            this.title = title;       // Sets the title of the film.
            this.director = director; // Sets the director of the film.
            this.quantity = quantity; // Sets the quantity available.
        }

        // Property to get and set the title of the film.
        public string Title
        {
            get { return title; }     // Returns the title of the film.
            set { title = value; }    // Updates the title of the film.
        }

        // Property to get and set the director of the film.
        public string Director
        {
            get { return director; }     // Returns the director of the film.
            set { director = value; }    // Updates the director of the film.
        }

        // Property to get and set the quantity of the film available.
        public int Quantity
        {
            get { return quantity; }     // Returns the quantity available.
            set { quantity = value; }    // Updates the quantity available.
        }

        // Implementation of the CompareTo method to allow films to be compared by title.
        public int CompareTo(object obj)
        {
            Film other = (Film)obj;             // Casts the object to a Film type.
            return Title.CompareTo(other.Title); // Compares titles alphabetically.
        }

        // Overrides the ToString method to display the film's information.
        public override string ToString()
        {
            // Returns a formatted string with the title, director, and quantity.
            return $"Title: {Title}, Director: {Director}, Quantity: {Quantity}";
        }
    } // End of Film class.
} // End of namespace.
