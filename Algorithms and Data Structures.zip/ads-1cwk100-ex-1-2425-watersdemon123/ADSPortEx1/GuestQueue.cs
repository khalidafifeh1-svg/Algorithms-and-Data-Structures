﻿using ADSPortEx1;
// Imports the ADSPortEx1 namespace to access the Guest class.
using System.Collections.Generic;
// Imports the System.Collections.Generic namespace to use collections like List<Guest>.
using System;
using NUnit.Framework;
using System.Collections;
using System.Security.Cryptography;
// Imports common classes from the System namespace.

class GuestQueue
{
    private int maxSize = 10;     // Maximum size of the queue.
    private Guest[] store;        // Array to hold the guests.
    private int head = 0;         // Pointer to the front of the queue.
    private int tail = 0;         // Pointer to the rear of the queue.
    private int numItems = 0;     // The number of items in the queue.

    public GuestQueue()
    {
        store = new Guest[maxSize];
        // Sets the queue size to maxSize (default is 10).
        // The queue will never exceed a size of 10.
    }

    // Constructor with custom size.
    public GuestQueue(int size)
    {
        maxSize = size;
        store = new Guest[maxSize];
        // Sets the queue size to the provided custom size.
        // Creates a store array based on the given size.
    }

    // Enqueue method for adding a guest to the queue.
    public void Enqueue(Guest value)
    {
        if (IsFull())
        // Checks if the queue is full.
        {
            head = (head + 1 == maxSize) ? 0 : head + 1;
            // Moves the head pointer forward to overwrite the oldest guest in the queue.
            // If head reaches maxSize, it wraps around to 0.
        }
        else
        {
            numItems++;
            // Increases numItems if the queue is not full.
        }

        store[tail] = value;
        // Adds the new guest at the current tail index.

        if (tail + 1 == maxSize)
        // Checks if moving the tail pointer will exceed the array's bounds.
        {
            tail = 0;
            // If true, the tail wraps around to the start of the array.
        }
        else
        {
            tail++;
            // Increments the tail pointer to add the next guest.
        }
    }

    // Dequeue method for removing a guest from the queue.
    public Guest Dequeue()
    {
        // Retrieves the guest at the front of the queue, which is at the 'head' index.
        Guest headItem = store[head];

        // Moves the head pointer forward and wraps around if necessary.
        if (head + 1 == maxSize)
        // If the head pointer is at the last index, the next position would be out of bounds.
        {
            head = 0;
            // If true, the head wraps around to the first position to maintain a circular buffer.
        }
        else
        {
            head++;
            // If false, simply increments the head pointer to point to the next guest.
        }

        numItems--;  // Decreases numItems since a guest was removed.
        return headItem;
        // Returns the guest that was removed (dequeued).
    }

    // Peek method to view the front item without removing it.
    public Guest Peek()
    {
        if (IsEmpty())
            // Checks if the queue is empty.
            throw new InvalidOperationException("Queue is empty.");
        // Throws an exception if the queue is empty.
        return store[head];
        // Returns the guest at the head position without removing it.
    }

    // Count method to get the number of items in the queue.
    public int Count()
    {
        return numItems;
        // Returns the number of guests currently in the queue.
    }

    // Check if the queue is empty.
    public bool IsEmpty()
    {
        return numItems == 0;
        // Returns true if the queue is empty (numItems is 0).
    }

    // Check if the queue is full.
    public bool IsFull()
    {
        return numItems == maxSize;
        // Returns true if the queue is full (numItems equals maxSize).
    }
    public void Reverse(int k)
    {
        if (k <= 0 || k > numItems)
            throw new ArgumentException("Invalid value for k. Must be between 1 and the current queue size.");
        // Throws an exception if k is invalid (less than or equal to 0, or greater than numItems).

        int start = head; // Starting index of the queue.
        int end = head + k - 1;
        // End index of the range to reverse, determined by the value of k.

        for (int i = 0; i < k / 2; i++)
        // Loops to swap the elements in the range (from start to end).
        {
            int index1 = start + i;
            int index2 = end - i;
            // Calculates the indices of the elements to swap.

            if (index1 >= maxSize)
                index1 -= maxSize;
            // Ensures the index wraps around if it exceeds maxSize.

            if (index2 >= maxSize)
                index2 -= maxSize;
            // Ensures the index wraps around if it exceeds maxSize.

            if (index1 < 0)
                index1 += maxSize;  // Wraps index1 around if it is negative.

            if (index2 < 0)
                index2 += maxSize;  // Wraps index2 around if it is negative.

            Guest temp = store[index1];
            // Saves the guest at index1 in a temporary variable.

            store[index1] = store[index2];
            // Sets the guest at index1 to the guest at index2.

            store[index2] = temp;
            // Places the guest stored in temp at index2.
        }
    }

    public List<Guest> GetAllGuests()
    // This method returns a list of all guests currently in the queue.
    {
        List<Guest> guests = new List<Guest>();
        // Creates a new list of guests.

        for (int i = 0; i < numItems; i++)
        // Loops through each guest in the queue.
        {
            int index = head + i;
            // Calculates the index of the current guest to add to the list.

            if (index >= maxSize)
                index -= maxSize;
            // Wraps the index around if it exceeds maxSize.

            guests.Add(store[index]);
            // Adds the guest at the calculated index to the list.
        }

        return guests;
        // Returns the list of guests in the queue.
    }

    // Find the guest with the most funds.
    public Guest FindGuestWithMostFunds()
    {
        if (IsEmpty())
            throw new InvalidOperationException("Queue is empty.");
        // Throws an exception if the queue is empty.

        Guest richestGuest = store[head];
        // Initializes the richest guest to the guest at the head of the queue.

        for (int i = 1; i < numItems; i++)
        // Loops through the rest of the guests in the queue.
        {
            int index = head + i;
            // Calculates the index of the current guest in the loop.

            if (index >= maxSize)
                index -= maxSize;
            // Wraps the index around if it exceeds maxSize.

            if (store[index].Funds > richestGuest.Funds)
            {
                richestGuest = store[index];
                // If the current guest has more funds than the richestGuest,
                // updates richestGuest to the current guest.
            }
        }

        return richestGuest;
        // Returns the guest with the most funds in the queue.
    }
}

    // Reverse the first k elements in the queue.


