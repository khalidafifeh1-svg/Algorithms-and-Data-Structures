﻿namespace ADSPortEx1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeadGuest = new System.Windows.Forms.Label();
            this.queueStatusLabel = new System.Windows.Forms.Label();
            this.tnFindRichestGuest = new System.Windows.Forms.Button();
            this.btnReverse = new System.Windows.Forms.Button();
            this.btnDequeue = new System.Windows.Forms.Button();
            this.countLabel = new System.Windows.Forms.Label();
            this.txtK = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lstQueue = new System.Windows.Forms.ListBox();
            this.btnEnqueue = new System.Windows.Forms.Button();
            this.fundsTextBox = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblHeadGuest
            // 
            this.lblHeadGuest.AutoSize = true;
            this.lblHeadGuest.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.lblHeadGuest.Location = new System.Drawing.Point(26, 325);
            this.lblHeadGuest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeadGuest.Name = "lblHeadGuest";
            this.lblHeadGuest.Size = new System.Drawing.Size(266, 57);
            this.lblHeadGuest.TabIndex = 39;
            this.lblHeadGuest.Text = "First Guest";
            // 
            // queueStatusLabel
            // 
            this.queueStatusLabel.AutoSize = true;
            this.queueStatusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.queueStatusLabel.Location = new System.Drawing.Point(1358, 31);
            this.queueStatusLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.queueStatusLabel.Name = "queueStatusLabel";
            this.queueStatusLabel.Size = new System.Drawing.Size(237, 42);
            this.queueStatusLabel.TabIndex = 38;
            this.queueStatusLabel.Text = "QueueStatus";
            // 
            // tnFindRichestGuest
            // 
            this.tnFindRichestGuest.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tnFindRichestGuest.Location = new System.Drawing.Point(1150, 910);
            this.tnFindRichestGuest.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tnFindRichestGuest.Name = "tnFindRichestGuest";
            this.tnFindRichestGuest.Size = new System.Drawing.Size(384, 127);
            this.tnFindRichestGuest.TabIndex = 37;
            this.tnFindRichestGuest.Text = "Most Funds";
            this.tnFindRichestGuest.UseVisualStyleBackColor = false;
            this.tnFindRichestGuest.UseWaitCursor = true;
            // 
            // btnReverse
            // 
            this.btnReverse.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnReverse.Location = new System.Drawing.Point(14, 721);
            this.btnReverse.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(294, 108);
            this.btnReverse.TabIndex = 36;
            this.btnReverse.Text = "Reverse";
            this.btnReverse.UseVisualStyleBackColor = false;
            // 
            // btnDequeue
            // 
            this.btnDequeue.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDequeue.Location = new System.Drawing.Point(36, 440);
            this.btnDequeue.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDequeue.Name = "btnDequeue";
            this.btnDequeue.Size = new System.Drawing.Size(312, 100);
            this.btnDequeue.TabIndex = 35;
            this.btnDequeue.Text = "Delete Guest";
            this.btnDequeue.UseVisualStyleBackColor = false;
            // 
            // countLabel
            // 
            this.countLabel.AutoSize = true;
            this.countLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.countLabel.Location = new System.Drawing.Point(954, 31);
            this.countLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.countLabel.Name = "countLabel";
            this.countLabel.Size = new System.Drawing.Size(260, 55);
            this.countLabel.TabIndex = 34;
            this.countLabel.Text = "countLabel";
            // 
            // txtK
            // 
            this.txtK.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtK.Font = new System.Drawing.Font("Microsoft Sans Serif", 33F);
            this.txtK.Location = new System.Drawing.Point(314, 721);
            this.txtK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtK.Name = "txtK";
            this.txtK.Size = new System.Drawing.Size(228, 107);
            this.txtK.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(18, 217);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(328, 61);
            this.label3.TabIndex = 31;
            this.label3.Text = "Guest Funds";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 123);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(340, 61);
            this.label2.TabIndex = 30;
            this.label2.Text = "Guest names";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 25);
            this.label1.TabIndex = 29;
            // 
            // lstQueue
            // 
            this.lstQueue.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lstQueue.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstQueue.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lstQueue.FormattingEnabled = true;
            this.lstQueue.ItemHeight = 61;
            this.lstQueue.Location = new System.Drawing.Point(954, 92);
            this.lstQueue.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.lstQueue.Name = "lstQueue";
            this.lstQueue.Size = new System.Drawing.Size(706, 553);
            this.lstQueue.TabIndex = 28;
            // 
            // btnEnqueue
            // 
            this.btnEnqueue.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnEnqueue.Location = new System.Drawing.Point(344, 440);
            this.btnEnqueue.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnEnqueue.Name = "btnEnqueue";
            this.btnEnqueue.Size = new System.Drawing.Size(312, 100);
            this.btnEnqueue.TabIndex = 27;
            this.btnEnqueue.Text = "Add Guest";
            this.btnEnqueue.UseVisualStyleBackColor = false;
            this.btnEnqueue.Click += new System.EventHandler(this.EnqueueButton_Click);
            // 
            // fundsTextBox
            // 
            this.fundsTextBox.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.fundsTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fundsTextBox.Location = new System.Drawing.Point(386, 212);
            this.fundsTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fundsTextBox.Name = "fundsTextBox";
            this.fundsTextBox.Size = new System.Drawing.Size(244, 67);
            this.fundsTextBox.TabIndex = 26;
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(386, 123);
            this.txtName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(244, 67);
            this.txtName.TabIndex = 33;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1814, 1088);
            this.Controls.Add(this.lblHeadGuest);
            this.Controls.Add(this.queueStatusLabel);
            this.Controls.Add(this.tnFindRichestGuest);
            this.Controls.Add(this.btnReverse);
            this.Controls.Add(this.btnDequeue);
            this.Controls.Add(this.countLabel);
            this.Controls.Add(this.txtK);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstQueue);
            this.Controls.Add(this.btnEnqueue);
            this.Controls.Add(this.fundsTextBox);
            this.Controls.Add(this.txtName);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeadGuest;
        private System.Windows.Forms.Label queueStatusLabel;
        private System.Windows.Forms.Button tnFindRichestGuest;
        private System.Windows.Forms.Button btnReverse;
        private System.Windows.Forms.Button btnDequeue;
        private System.Windows.Forms.Label countLabel;
        private System.Windows.Forms.TextBox txtK;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstQueue;
        private System.Windows.Forms.Button btnEnqueue;
        private System.Windows.Forms.TextBox fundsTextBox;
        private System.Windows.Forms.TextBox txtName;
    }
}

