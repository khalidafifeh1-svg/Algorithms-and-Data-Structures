﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADSPortEx1
{

    //Guest class implementation for use with 
    // GuestQueue structure

    //Do not delete the current function definitions, just replace the exceptions with the required functionality...

    //See material from 'C# Classes' in week 2 to 
    // aid with implementation...

    // Guest class implementation for use with GuestQueue structure

    class Guest : IComparable
    {
        // Private fields to store the guest's name and funds.
        private string name;
        private double funds;

        // Constructor to initialize the Guest object with a name and funds.
        public Guest(string name, double funds)
        {
            this.name = name; // Assigns the parameter value to the name field.
            this.funds = funds; // Assigns the parameter value to the funds field.
        }

        // Property to access and modify the name field.
        public string Name
        {
            get { return name; } // Returns the current value of the name.
            set { name = value; } // Updates the name field with a new value.
        }

        // Property to access and modify the funds field.
        public double Funds
        {
            get { return funds; } // Returns the current value of the funds.
            set { funds = value; } // Updates the funds field with a new value.
        }

        // Implementation of CompareTo method for comparing Guest objects by name.
        public int CompareTo(object obj)
        {
            Guest other = (Guest)obj; // Casts the object to a Guest type.
            return name.CompareTo(other.Name); // Compares the names alphabetically.
        }

        // Overrides the ToString method to display the guest's information.
        public override string ToString()
        {
            // The '$' symbol enables string interpolation, embedding variables in the string.
            // The '£' symbol is used here as a literal to indicate the currency (GBP).
            // 'F2' is a format specifier that formats the 'funds' value to display exactly two decimal places.
            return $"Name: {name}, Funds: £{funds:F2}";
        }
    }// End of class...

}
