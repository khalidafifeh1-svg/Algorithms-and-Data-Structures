﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADSPortEx1
{
    public partial class Form1 : Form
    {
        private GuestQueue guestQueue; // Guest queue instance to manage guests.

        // Constructor: Initializes the form and the guest queue.
        public Form1()
        {
            InitializeComponent();
            guestQueue = new GuestQueue(); // Initialize the queue with the default size.
            UpdateHeadLabel(); // Update the label displaying the head guest.
            UpdateQueueStatus(); // Update the queue status (full, empty, or has guests).
        }

        // Updates the label to show the guest at the head of the queue.
        private void UpdateHeadLabel()
        {
            if (guestQueue.IsEmpty())
            {
                lblHeadGuest.Text = "Queue is empty."; // Indicate the queue is empty.
            }
            else
            {
                Guest headGuest = guestQueue.Peek(); // Retrieve the guest at the head of the queue.
                lblHeadGuest.Text = $"Head: {headGuest.Name} with funds: £{headGuest.Funds:F2}"; // Display guest details.
            }
        }

        // Adds a guest to the queue when the "Enqueue" button is clicked.
        private void EnqueueButton_Click(object sender, EventArgs e)
        {
            if (double.TryParse(fundsTextBox.Text, out double funds)) // Validate that funds input is a valid number.
            {
                if (guestQueue.IsFull())
                {
                    MessageBox.Show("Cannot add guest. The queue is full."); // Show an error if the queue is full.
                    return;
                }

                var guest = new Guest(txtName.Text, funds); // Create a new guest with the given name and funds.
                guestQueue.Enqueue(guest); // Add the guest to the queue.

                UpdateQueueStatus(); // Update the queue status after adding a guest.
                countLabel.Text = "Count: " + guestQueue.Count(); // Update the count label.
                lstQueue.Items.Add(guest.ToString()); // Add the guest's details to the list box.
                UpdateHeadLabel(); // Refresh the head label.
            }
            else
            {
                MessageBox.Show("Please enter a valid amount for funds and enter name of guest."); // Show an error for invalid input.
            }
        }

        // Removes a guest from the queue when the "Dequeue" button is clicked.
        private void btnDequeue_Click(object sender, EventArgs e)
        {
            if (guestQueue.IsEmpty())
            {
                MessageBox.Show("No guests in the queue."); // Show an error if the queue is empty.
                return;
            }

            var nextGuest = guestQueue.Dequeue(); // Remove the guest from the head of the queue.
            lstQueue.Text = nextGuest.ToString(); // Display the removed guest's details.
            countLabel.Text = "Count: " + guestQueue.Count(); // Update the count label.

            UpdateJobList(); // Refresh the list box to reflect the current queue.
            UpdateQueueStatus(); // Update the queue status.
            UpdateHeadLabel(); // Update the label displaying the head guest.
        }

        // Reverses the first 'k' guests in the queue when the "Reverse" button is clicked.
        private void btnReverse_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtK.Text, out int k)) // Validate that 'k' is a valid number.
            {
                guestQueue.Reverse(k); // Reverse the first 'k' elements in the queue.
                UpdateJobList(); // Refresh the list box to reflect the changes.
                UpdateQueueStatus(); // Update the queue status.
                UpdateHeadLabel(); // Update the head guest label.
            }
            else
            {
                MessageBox.Show("Please enter a valid number for k."); // Show an error for invalid input.
            }
        }

        // Finds and displays the richest guest in the queue.
        private void tnFindRichestGuest_Click(object sender, EventArgs e)
        {
            try
            {
                Guest richestGuest = guestQueue.FindGuestWithMostFunds(); // Find the guest with the most funds.
                MessageBox.Show($"The richest guest is: {richestGuest.Name} with funds: £{richestGuest.Funds:F2}",
                                "Richest Guest", // Message box title.
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information); // Display the richest guest's details.
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message); // Show an error if the queue is empty.
            }
        }

        // Refreshes the list box to display all guests currently in the queue.
        private void UpdateJobList()
        {
            lstQueue.Items.Clear(); // Clear the list box.

            // Retrieve the list of all guests in the queue.
            List<Guest> guests = guestQueue.GetAllGuests();

            // Add each guest's details to the list box.
            foreach (Guest guest in guests)
            {
                lstQueue.Items.Add(guest.ToString());
            }
        }

        // Updates the queue status label to show whether the queue is full, empty, or contains guests.
        private void UpdateQueueStatus()
        {
            if (guestQueue.IsFull())
            {
                queueStatusLabel.Text = "Queue is Full";
                queueStatusLabel.ForeColor = Color.Red; // Set text color to red.
            }
            else if (guestQueue.IsEmpty())
            {
                queueStatusLabel.Text = "Queue is Empty";
                queueStatusLabel.ForeColor = Color.Green; // Set text color to green.
            }
            else
            {
                queueStatusLabel.Text = "Guests in Queue";
                queueStatusLabel.ForeColor = Color.Blue; // Set text color to blue.
            }
        }

        // Placeholder for the TextChanged event of the txtK TextBox.
        private void txtK_TextChanged(object sender, EventArgs e)
        {
        }

        // Placeholder for the Click event of label3.
        private void label3_Click(object sender, EventArgs e)
        {
        }

        // Placeholder for the TextChanged event of the fundsTextBox.
        private void fundsTextBox_TextChanged(object sender, EventArgs e)
        {
        }

        // Placeholder for the Click event of label2.
        private void label2_Click(object sender, EventArgs e)
        {
        }

        // Placeholder for the Click event of the countLabel.
        private void countLabel_Click(object sender, EventArgs e)
        {
        }

        // Placeholder for the TextChanged event of txtName TextBox.
        private void txtName_TextChanged(object sender, EventArgs e)
        {
        }

        // Placeholder for the Click event of lblHeadGuest.
        private void lblHeadGuest_Click(object sender, EventArgs e)
        {
        }

        // Placeholder for the SelectedIndexChanged event of lstQueue.
        private void lstQueue_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        // Placeholder for the Click event of queueStatusLabel.
        private void queueStatusLabel_Click(object sender, EventArgs e)
        {
        }
    }
}
